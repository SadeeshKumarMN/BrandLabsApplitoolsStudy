package BrandLabsQC.DemoMOATSSeleniumApplitools;

/**
 * Hello world!- Sample Code created by Maven
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
