package BrandLabsQC.DemoMOATSSeleniumApplitools;

import org.testng.annotations.Test;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.RectangleSize;
import java.rmi.UnexpectedException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

/**
 * @author Sadeesh.Kumar@brandlabs.us
 * Applitools Eyes Case Study for Visual Automation
 * Created on 18-Sep-2018
 *
 */
public class VisualAutomationMOAT {
	public static CompareEyes eyes;
	public static WebDriver driver;

	@Parameters("browser")

	@BeforeClass
	// Passing Browser parameter from TestNG xml
	public void beforeTest(String browser) {

		// If the browser is Firefox, then do this
		if (browser.equalsIgnoreCase("firefox")) {
			// Here I am setting up the path for my FirefoxDriver
			System.setProperty("webdriver.gecko.driver", "F:\\Tools_Drivers\\geckodriver-v0.21.0-win64\\geckodriver.exe");
			// Initialize/Open the Firefox Driver
			driver = new FirefoxDriver();

		} else if (browser.equalsIgnoreCase("edge")) {
			// Here I am setting up the path for my Microsoft Edge Driver
			System.setProperty("webdriver.edge.driver", "F:\\Tools_Drivers\\MicrosoftWebDriver.exe");
			// Initialize/Open the Microsoft Edge Driver
			driver = new EdgeDriver();

		} else {
			// Here I am setting up the path for my Chrome Driver
			System.setProperty("webdriver.chrome.driver", "F:\\Tools_Drivers\\chromedriver_win32\\chromedriver.exe");
			// Initialize/Open the Chrome Driver
			driver = new ChromeDriver();

		}

		// Initialize the Applitools Eyes SDK
		eyes = new CompareEyes();
		
		// Set My Account API Key
		eyes.setApiKey("MJw6EbcrYioGUphu0BPA8XbxjsTd128mCsZrDNZFNyM110");
		
		//Forces a full page screenshot
		eyes.setForceFullPageScreenshot(true);
		
		//setBatch is a helpful Applitools Eyes command whichs gather multiple tests and run them together. 
		eyes.setBatch(new BatchInfo("Comparison"));
		
		//Enable Comparision mode for comparing 2 diff urls under test
		eyes.setEnableComparison(true);

	}

	// Once Before method is completed, Test method will start
	@Test
	public void login() throws InterruptedException, UnexpectedException {
		// Start the test and set my browser's viewport size to 1518, 654
		eyes.open(driver, "MOAT Login Demo!", "MOAT Login Demo!", new RectangleSize(1518, 654));
		
		// Code for validating MOAT- Dev Environment-Baseline Images
		checkFirstEnvironment();
		
		// Use the same browser driver instance for preparing to execute MOAT- Production Environment
		eyes.switchToComparisonMode(driver);
		
		// Code for validating MOAT- Production Environment- Checkpoint Images
		checkSecondEnvironment();

	}

	public static void checkFirstEnvironment() {

		// Launch the BaseUrl
		driver.get("http://moat-dev-site-14.mybigcommerce.com/");

		// Verify the Page Title
		driver.getTitle().equals("MOAT - Dev Site 1 - Order Status");

		// Call Common Reusable Codes for both the environments
		commonTestSteps();

	}

	public static void checkSecondEnvironment() {

		// Launch the BaseUrl
		driver.get("https://www.macofalltrades.com/");

		// Verify the Page Title
		driver.getTitle().equals("Used Macs - Refurbished Macs Computers | Mac of All Trades");

		// Call Common Reusable Codes for both the environments
		commonTestSteps();
	}

	public static void commonTestSteps() {
		// Synchronization- Wait for Page to be loaded
		eyes.waitForLoad(driver);

		// Visual checkpoint #1.
		eyes.checkWindow("Home");

		// Click the Login Link
		driver.findElement(By.cssSelector("a.nav-user-item-chat:nth-child(2)")).click();

		// Call a Custom Code for all the Page Elements are loaded(Synchronization/Wait)
		eyes.waitForLoad(driver);

		// Visual checkpoint #2.
		eyes.checkWindow("Login");

		// Submit Login Form
		driver.findElement(By.id("login_email")).sendKeys("brandlabstest@gmail.com");

		driver.findElement(By.id("login_pass")).sendKeys("test@123");

		driver.findElement(By.xpath("//*[@class='button button--primary' and @value='Sign in']")).click();

		// Call a Custom Code for all the Page Elements are loaded(Synchronization/Wait)
		eyes.waitForLoad(driver);

		// Visual checkpoint #3.
		eyes.checkWindow("Login Successful");
	}

	@AfterClass
	public void afterTest() {

		// End the test
		eyes.close();
		
		// Close the browser.
		driver.quit();
		
		// If the test was aborted before eyes.close was called, ends the test as aborted.
		eyes.abortIfNotClosed();

	}

}