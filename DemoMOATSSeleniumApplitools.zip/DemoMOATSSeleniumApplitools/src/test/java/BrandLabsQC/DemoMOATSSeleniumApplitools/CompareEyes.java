package BrandLabsQC.DemoMOATSSeleniumApplitools;

import java.rmi.UnexpectedException;

import javax.ws.rs.NotSupportedException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.TestResults;
import com.applitools.eyes.selenium.Eyes;

/**
 * Helper Class provided by Applitools Eyes for Comparing URLS
 *
 */

public class CompareEyes extends Eyes {
	
	private boolean isComparisonEnabled = false;
	
	private boolean isInBaselineMode = true;
	BatchInfo batchInfo = null;
	
	private String appName;
	private String testName;
	private RectangleSize viewportSize;
	
	// Public Methods
	@Override
	public WebDriver open(WebDriver driver, String appName, String testName, RectangleSize viewportSize) {
		
		if (this.isComparisonEnabled){
			close();
			
				this.appName = appName;
				this.testName = testName;
				this.viewportSize = viewportSize;
				
				this.setSaveFailedTests(true);
				this.isInBaselineMode = true;
			
			WebDriver newdriver = super.open(driver, appName, testName, viewportSize);
			
			return newdriver;
		}
		else{
			return super.open(driver, appName, testName, viewportSize);
		}
	}
	
	@Override
	public WebDriver open(WebDriver driver, String appName, String testName) {
		
		if (isComparisonEnabled){
			throw new NotSupportedException("This overload is not supported in comparison mode.");
		}
		
		return super.open(driver, appName, testName);
	}
	
	public void switchToComparisonMode(WebDriver driver) throws UnexpectedException {
		
		if (!isComparisonEnabled){
			throw new UnexpectedException("Comparison Mode is not enabled!");
		}
		
		close();
		
		this.setSaveFailedTests(false);
		this.isInBaselineMode = false;
		
		
		super.open(driver, appName, testName, viewportSize);
	}
	
	@Override
	public TestResults close(boolean throwException) {
		
		if (this.isComparisonEnabled){
			TestResults testResults = null;
			
			if (this.getIsOpen()){
				if (this.isInBaselineMode){
					testResults = super.close(false);
					
					if (this.getBatch() != null){
						testResults.delete();
					}
				}
				else{
					testResults = super.close(throwException);
				}
			}
			
			return testResults;
		}
		else
		{
			return super.close(throwException);
		}
	}

	public void setEnableComparison(boolean enableComparison) {
		this.isComparisonEnabled = enableComparison;
	}
	
	public boolean getEnableComparison(){
		return this.isComparisonEnabled;
	}
	
	public void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(pageLoadCondition);

	}

}
